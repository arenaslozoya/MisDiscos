import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Album1Page } from './album1';

@NgModule({
  declarations: [
    Album1Page,
  ],
  imports: [
    IonicPageModule.forChild(Album1Page),
  ],
})
export class Album1PageModule {}
