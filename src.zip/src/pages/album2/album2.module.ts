import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Album2Page } from './album2';

@NgModule({
  declarations: [
    Album2Page,
  ],
  imports: [
    IonicPageModule.forChild(Album2Page),
  ],
})
export class Album2PageModule {}
