import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Caratula2Page } from './caratula2';

@NgModule({
  declarations: [
    Caratula2Page,
  ],
  imports: [
    IonicPageModule.forChild(Caratula2Page),
  ],
})
export class Caratula2PageModule {}
