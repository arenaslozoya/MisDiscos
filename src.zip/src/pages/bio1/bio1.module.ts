import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Bio1Page } from './bio1';

@NgModule({
  declarations: [
    Bio1Page,
  ],
  imports: [
    IonicPageModule.forChild(Bio1Page),
  ],
})
export class Bio1PageModule {}
