import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { Reseña1Page } from './reseña1';

@NgModule({
  declarations: [
    Reseña1Page,
  ],
  imports: [
    IonicPageModule.forChild(Reseña1Page),
  ],
})
export class Reseña1PageModule {}
